<?php
require("conexaobd.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['idConsulta'])) {
    $idConsulta = intval($_POST['idConsulta']); // Usando $_POST ao invés de $_GET

    $query = "UPDATE consultas_marcadas SET status = 'Cancelada' WHERE idConsulta = ?";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(1, $idConsulta, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Consulta cancelada com sucesso.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao cancelar consulta.']);
    }
}
