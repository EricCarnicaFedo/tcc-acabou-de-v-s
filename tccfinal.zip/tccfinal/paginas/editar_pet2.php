<?php
require("conexaobd.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $petId = $_POST['id'];
    $nome = $_POST['nome'];
    $especie = $_POST['especie'];
    $raca = $_POST['raca'];
    $idade = $_POST['idade'];

    $query = "UPDATE pets SET nome = ?, especie = ?, raca = ?, idade = ? WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$nome, $especie, $raca, $idade, $petId]);

    echo "Pet atualizado com sucesso!";
    header("Location: petstutor.php");
    exit();
}

if (isset($_GET['id'])) {
    $petId = $_GET['id'];
    $query = "SELECT * FROM pets WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$petId]);
    $pet = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Pet</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f4f8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        form {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            color: #333;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 0.75rem;
            margin-bottom: 1rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        button {
            width: 100%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <?php
    require("conexaobd.php");
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $petId = $_POST['id'];
        $nome = $_POST['nome'];
        $especie = $_POST['especie'];
        $raca = $_POST['raca'];
        $idade = $_POST['idade'];
        $query = "UPDATE pets SET nome = ?, especie = ?, raca = ?, idade = ? WHERE id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$nome, $especie, $raca, $idade, $petId]);
        echo "Pet atualizado com sucesso!";
        header("Location: petstutor.php");
        exit();
    }
    if (isset($_GET['id'])) {
        $petId = $_GET['id'];
        $query = "SELECT * FROM pets WHERE id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$petId]);
        $pet = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    ?>
    <form method="POST">
        <h2>Atualizar Pet</h2>
        <input type="hidden" name="id" value="<?php echo $pet['id']; ?>">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" value="<?php echo $pet['nome']; ?>" required>
        <label for="especie">Espécie:</label>
        <input type="text" id="especie" name="especie" value="<?php echo $pet['especie']; ?>" required>
        <label for="raca">Raça:</label>
        <input type="text" id="raca" name="raca" value="<?php echo $pet['raca']; ?>" required>
        <label for="idade">Idade:</label>
        <input type="number" id="idade" name="idade" value="<?php echo $pet['idade']; ?>" required>
        <button type="submit">Salvar</button>
    </form>
</body>
</html>


