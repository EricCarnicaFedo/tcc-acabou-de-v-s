<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificando se os parâmetros estão definidos
if (isset($_GET['id']) && isset($_GET['status'])) {
    $idPrescricao = $_GET['id'];
    $status = $_GET['status'];

    // Verificando se o status fornecido é válido
    if (in_array($status, ['Prescrito', 'Em uso', 'Concluído', 'Cancelado'])) {
        // Atualizando o status do medicamento
        $sql = "UPDATE medicamentos_prescritos SET status = ? WHERE idPrescricao = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $status, $idPrescricao);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Status do medicamento atualizado com sucesso!";
        } else {
            $_SESSION['message'] = "Erro ao atualizar o status: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['message'] = "Status inválido!";
    }
} else {
    $_SESSION['message'] = "ID ou Status não fornecidos!";
}

$conn->close();

// Redirecionando de volta para a página que lista os medicamentos
header("Location: pets.php");
exit();
?>
