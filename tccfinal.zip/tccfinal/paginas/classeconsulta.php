<?php
class Consulta
{
    private $idConsulta;
    private $proprietario; // Proprietário agora é uma string (varchar)
    private $dataConsulta;
    private $horaConsulta;
    private $descricao; // Adicionado campo descricao
    private $status;

    // Métodos setters
    public function setIdConsulta($valor) {
        $this->idConsulta = $valor;
    }

    public function setProprietario($valor) {
        $this->proprietario = $valor; // Armazena o nome ou identificação do proprietário
    }

    public function setDataConsulta($valor) {
        $this->dataConsulta = $valor;
    }

    public function setHoraConsulta($valor) {
        $this->horaConsulta = $valor;
    }

    public function setDescricao($valor) { // Adicionado setter para descricao
        $this->descricao = $valor;
    }

    public function setStatus($valor) {
        $this->status = $valor;
    }

    // Métodos getters
    public function getIdConsulta() {
        return $this->idConsulta;
    }

    public function getProprietario() {
        return $this->proprietario; // Retorna o nome ou identificação do proprietário
    }

    public function getDataConsulta() {
        return $this->dataConsulta;
    }

    public function getHoraConsulta() {
        return $this->horaConsulta;
    }

    public function getDescricao() { // Adicionado getter para descricao
        return $this->descricao;
    }

    public function getStatus() {
        return $this->status;
    }

    // Listar todas as consultas para uma clínica
    public function listar($clinica_id) {
        require("conexaobd.php");
    
        // A consulta agora usa um JOIN entre tutores e consultas_marcadas para trazer as consultas relacionadas à clínica
        $consulta = "
        SELECT c.* 
        FROM consultas_marcadas c
        JOIN tutores t ON c.tutor_id = t.id
        WHERE t.clinica_id = :clinica_id
        ORDER BY c.data_consulta, c.hora_consulta;
        ";
    
        try {
            $resultado = $pdo->prepare($consulta);
            $resultado->bindParam(':clinica_id', $clinica_id, PDO::PARAM_INT);
            $resultado->execute();
    
            // Verificar se há registros
            if ($resultado->rowCount() > 0) {
                return $resultado->fetchAll(PDO::FETCH_ASSOC);
            } else {
                echo "Nenhuma consulta encontrada.";
                return [];
            }
        } catch (PDOException $e) {
            echo "Erro na consulta: " . $e->getMessage();
            return [];
        }
    }
    
    // Consultar uma consulta específica
    public function consultar($idConsulta) {
        require("conexaobd.php");

        $comando = "SELECT * FROM consultas_marcadas WHERE idConsulta = :idConsulta";
        $resultado = $pdo->prepare($comando);
        $resultado->bindParam(":idConsulta", $idConsulta);
        $resultado->execute();

        if ($resultado->rowCount() == 1) {
            $registro = $resultado->fetch(PDO::FETCH_ASSOC);
            $this->idConsulta = $registro["idConsulta"];
            $this->proprietario = $registro["proprietario"]; // Agora armazena o nome do proprietário
            $this->dataConsulta = $registro["data_consulta"];
            $this->horaConsulta = $registro["hora_consulta"];
            $this->descricao = $registro["descricao"]; // Agora captura a descrição
            $this->status = $registro["status"];
            return true;
        }
        return false;
    }

    // Inserir uma nova consulta
    public function inserir($nomeAnimal, $dataConsulta, $horaConsulta, $descricao, $status, $petId, $tutorId) {
        require("conexaobd.php");
    
        // Alterando o comando para refletir a estrutura correta da tabela
        $comando = "INSERT INTO consultas_marcadas (nome_animal, data_consulta, hora_consulta, descricao, status, pet_id, tutor_id) 
                    VALUES (:nomeAnimal, :dataConsulta, :horaConsulta, :descricao, :status, :petId, :tutorId)";
        
        $resultado = $pdo->prepare($comando);
        $resultado->bindParam(':nomeAnimal', $nomeAnimal); // Nome do animal
        $resultado->bindParam(':dataConsulta', $dataConsulta);
        $resultado->bindParam(':horaConsulta', $horaConsulta);
        $resultado->bindParam(':descricao', $descricao); // Descrição da consulta
        $resultado->bindParam(':status', $status); // Status da consulta
        $resultado->bindParam(':petId', $petId); // ID do pet
        $resultado->bindParam(':tutorId', $tutorId); // ID do tutor
    
        $resultado->execute();
    
        return ($resultado->rowCount() == 1) ? true : false;
    }
    

    // Alterar uma consulta
    public function alterar($idConsulta, $proprietario, $dataConsulta, $horaConsulta, $descricao, $status) {
        require("conexaobd.php");

        $comando = "UPDATE consultas_marcadas 
                    SET proprietario = :proprietario, 
                        data_consulta = :dataConsulta, hora_consulta = :horaConsulta, descricao = :descricao, status = :status 
                    WHERE idConsulta = :idConsulta";
        $resultado = $pdo->prepare($comando);
        $resultado->bindParam(':idConsulta', $idConsulta);
        $resultado->bindParam(':proprietario', $proprietario); // Nome ou identificação do proprietário
        $resultado->bindParam(':dataConsulta', $dataConsulta);
        $resultado->bindParam(':horaConsulta', $horaConsulta);
        $resultado->bindParam(':descricao', $descricao); // Adicionado campo descricao
        $resultado->bindParam(':status', $status);
        $resultado->execute();

        return ($resultado->rowCount() == 1) ? true : false;
    }

    // Excluir uma consulta
    public function excluir($idConsulta) {
        require("conexaobd.php");

        $comando = "DELETE FROM consultas_marcadas WHERE idConsulta = :idConsulta";
        $resultado = $pdo->prepare($comando);
        $resultado->bindParam(':idConsulta', $idConsulta);
        $resultado->execute();

        return ($resultado->rowCount() == 1) ? true : false;
    }
}
?>
