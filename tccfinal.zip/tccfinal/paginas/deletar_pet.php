<?php
// Excluir pet
if (isset($_GET['delete_id'])) {
    require("conexaobd.php");

    $petId = $_GET['delete_id'];
    $tutorId = $_SESSION['tutor_id'];

    // Verificar se o pet pertence ao tutor logado
    $checkQuery = "SELECT id FROM pets WHERE id = ? AND tutor_id = ?";
    $stmt = $pdo->prepare($checkQuery);
    $stmt->bindParam(1, $petId, PDO::PARAM_INT);
    $stmt->bindParam(2, $tutorId, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        // Pet encontrado, excluir
        $deleteQuery = "DELETE FROM pets WHERE id = ?";
        $deleteStmt = $pdo->prepare($deleteQuery);
        $deleteStmt->bindParam(1, $petId, PDO::PARAM_INT);
        if ($deleteStmt->execute()) {
            echo "<script>alert('Pet excluído com sucesso!'); window.location='meus_pets.php';</script>";
        } else {
            echo "<script>alert('Erro ao excluir pet.');</script>";
        }
    } else {
        echo "<script>alert('Pet não encontrado.'); window.location='meus_pets.php';</script>";
    }
}
?>
