<?php
require("conexaobd.php");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $petId = $data['id'];

    try {
        $query = "DELETE FROM pets WHERE id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(1, $petId, PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}
