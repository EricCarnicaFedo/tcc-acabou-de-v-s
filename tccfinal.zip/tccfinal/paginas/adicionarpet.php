<?php
require("conexaobd.php");

// Verificar se o tutor está logado
if (!isset($_SESSION['tutor_id'])) {
    echo "<script>alert('Erro: Você não está logado como tutor.'); window.location='login.php';</script>";
    exit();
}

// Processar o formulário de adição de pet
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $especie = $_POST['especie'];
    $raca = $_POST['raca'];
    $idade = $_POST['idade'];
    $tutorId = $_SESSION['tutor_id'];

    // Inserir o novo pet
    $insertQuery = "INSERT INTO pets (nome, especie, raca, idade, tutor_id) VALUES (?, ?, ?, ?, ?)";
    $insertStmt = $pdo->prepare($insertQuery);
    $insertStmt->bindParam(1, $nome);
    $insertStmt->bindParam(2, $especie);
    $insertStmt->bindParam(3, $raca);
    $insertStmt->bindParam(4, $idade);
    $insertStmt->bindParam(5, $tutorId);
    
    if ($insertStmt->execute()) {
        echo "<script>alert('Pet adicionado com sucesso!'); window.location='meus_pets.php';</script>";
    } else {
        echo "<script>alert('Erro ao adicionar pet.');</script>";
    }
}
?>

<main class="p-6">
    <div class="bg-white p-6 rounded shadow-md">
        <h1 class="text-xl font-bold mb-6">Adicionar Novo Pet</h1>
        <form method="POST">
            <div class="mb-4">
                <label for="nome" class="block text-sm font-semibold">Nome do Pet</label>
                <input type="text" id="nome" name="nome" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="especie" class="block text-sm font-semibold">Espécie</label>
                <input type="text" id="especie" name="especie" class="w-full p-2 border rounded">
            </div>
            <div class="mb-4">
                <label for="raca" class="block text-sm font-semibold">Raça</label>
                <input type="text" id="raca" name="raca" class="w-full p-2 border rounded">
            </div>
            <div class="mb-4">
                <label for="idade" class="block text-sm font-semibold">Idade</label>
                <input type="number" id="idade" name="idade" class="w-full p-2 border rounded" required>
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Adicionar Pet</button>
        </form>
    </div>
</main>
