<?php
require("conexaobd.php");

// Verificar se o tutor está logado
if (!isset($_SESSION['tutor_id'])) {
    echo "<script>alert('Erro: Você não está logado como tutor.'); window.location='login.php';</script>";
    exit();
}

// Verificar se o ID do pet foi passado
if (!isset($_GET['id'])) {
    echo "<script>alert('Pet não encontrado.'); window.location='meus_pets.php';</script>";
    exit();
}

$petId = $_GET['id'];
$tutorId = $_SESSION['tutor_id'];

// Buscar os dados do pet
$query = "SELECT nome, especie, raca, idade FROM pets WHERE id = ? AND tutor_id = ?";
$stmt = $pdo->prepare($query);
$stmt->bindParam(1, $petId, PDO::PARAM_INT);
$stmt->bindParam(2, $tutorId, PDO::PARAM_INT);
$stmt->execute();

$pet = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$pet) {
    echo "<script>alert('Pet não encontrado.'); window.location='meus_pets.php';</script>";
    exit();
}

// Processar o formulário de edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $especie = $_POST['especie'];
    $raca = $_POST['raca'];
    $idade = $_POST['idade'];

    // Atualizar os dados do pet
    $updateQuery = "UPDATE pets SET nome = ?, especie = ?, raca = ?, idade = ? WHERE id = ?";
    $updateStmt = $pdo->prepare($updateQuery);
    $updateStmt->bindParam(1, $nome);
    $updateStmt->bindParam(2, $especie);
    $updateStmt->bindParam(3, $raca);
    $updateStmt->bindParam(4, $idade);
    $updateStmt->bindParam(5, $petId);
    
    if ($updateStmt->execute()) {
        echo "<script>alert('Pet atualizado com sucesso!'); window.location='meus_pets.php';</script>";
    } else {
        echo "<script>alert('Erro ao atualizar pet.');</script>";
    }
}
?>

<main class="p-6">
    <div class="bg-white p-6 rounded shadow-md">
        <h1 class="text-xl font-bold mb-6">Editar Pet</h1>
        <form method="POST">
            <div class="mb-4">
                <label for="nome" class="block text-sm font-semibold">Nome do Pet</label>
                <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($pet['nome']); ?>" class="w-full p-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label for="especie" class="block text-sm font-semibold">Espécie</label>
                <input type="text" id="especie" name="especie" value="<?php echo htmlspecialchars($pet['especie']); ?>" class="w-full p-2 border rounded">
            </div>
            <div class="mb-4">
                <label for="raca" class="block text-sm font-semibold">Raça</label>
                <input type="text" id="raca" name="raca" value="<?php echo htmlspecialchars($pet['raca']); ?>" class="w-full p-2 border rounded">
            </div>
            <div class="mb-4">
                <label for="idade" class="block text-sm font-semibold">Idade</label>
                <input type="number" id="idade" name="idade" value="<?php echo htmlspecialchars($pet['idade']); ?>" class="w-full p-2 border rounded" required>
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Salvar Alterações</button>
        </form>
    </div>
</main>
