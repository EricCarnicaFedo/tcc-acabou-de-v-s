<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if (isset($_GET['tutor_id'])) {
    $tutor_id = $_GET['tutor_id'];
    
    // Consultando os pets do tutor
    $query = "SELECT id, nome FROM pets WHERE tutor_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $tutor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $pets = [];
    while ($row = $result->fetch_assoc()) {
        $pets[] = $row;
    }

    // Retorna os pets como JSON
    echo json_encode($pets);
}

$stmt->close();
$conn->close();
?>
