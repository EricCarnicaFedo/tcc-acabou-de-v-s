<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificando se os parâmetros estão definidos
if (isset($_GET['id']) && isset($_GET['status'])) {
    $idTratamento = $_GET['id'];
    $status = $_GET['status'];

    // Verificando se o status fornecido é válido
    if (in_array($status, ['Cancelado', 'Concluído'])) {
        // Atualizando o status do tratamento
        $sql = "UPDATE tratamentos SET status = ? WHERE idTratamento = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $status, $idTratamento);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Status atualizado com sucesso!";
        } else {
            $_SESSION['message'] = "Erro ao atualizar o status: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['message'] = "Status inválido!";
    }
} else {
    $_SESSION['message'] = "ID ou Status não fornecidos!";
}

$conn->close();

// Redirecionando de volta para a página que lista os tratamentos
header("Location: pets.php");
exit();
?>
