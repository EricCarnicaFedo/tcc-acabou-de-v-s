<?php
include('conexaobd.php');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] != 'tutor') {
    header("Location: login.php");
    exit();
}

try {
    $conn = new PDO('mysql:host=localhost;dbname=tccdois', 'root', '');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "
        SELECT 
            pets.id AS pet_id, pets.nome, pets.especie, pets.raca, pets.idade,
            GROUP_CONCAT(DISTINCT medicamentos_prescritos.medicamento SEPARATOR ', ') AS medicamentos,
            GROUP_CONCAT(DISTINCT exames_realizados.tipoExame SEPARATOR ', ') AS exames,
            GROUP_CONCAT(DISTINCT historico_vacinas.tipoVacina SEPARATOR ', ') AS vacinas,
            GROUP_CONCAT(DISTINCT tratamentos.descricao SEPARATOR ', ') AS tratamentos
        FROM pets 
        LEFT JOIN tutores ON pets.tutor_id = tutores.id
        LEFT JOIN medicamentos_prescritos ON pets.id = medicamentos_prescritos.pet_id
        LEFT JOIN exames_realizados ON pets.id = exames_realizados.idPaciente
        LEFT JOIN historico_vacinas ON pets.id = historico_vacinas.idAnimal
        LEFT JOIN tratamentos ON pets.id = tratamentos.pet_id
        WHERE tutores.id = (
            SELECT id FROM tutores WHERE nome = (SELECT nome FROM usuarios WHERE id = :usuario_id)
        )
        GROUP BY pets.id";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':usuario_id', $_SESSION['usuario_id'], PDO::PARAM_INT);
    $stmt->execute();
    $pets = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p class='text-red-500'>Erro ao buscar informações: {$e->getMessage()}</p>";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ficha dos Pets</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="inicio.css">
    <link rel="stylesheet" href="style.css">
</head>
<header id="navbar" class="flex justify-between items-center text-white p-4">
    <nav>
        <div class="titulonavbar">
            <i class="bx bxs-animal-paw"></i>
            <span class="text">Pets</span>
        </div>
        <ul class="navbarconteudo">
            <!-- Manter apenas os itens desejados -->
        </ul>
    </nav>

    <div class="flex items-center space-x-4">
        <!-- Verifica se o nome do usuário está na sessão -->
        <span class="hidden md:inline-block">Bem-vindo, <?php echo isset($_SESSION['nome_usuario']) ? $_SESSION['nome_usuario'] : 'Usuário'; ?></span>

        <a href="logout.php" class="hover:underline">Sair</a>
        <i class="bx bx-bell"></i>
        <img src="https://placehold.co/30x30" alt="User avatar" class="w-8 h-8 rounded-full">
    </div>

    <i class='bx bx-menu menu-button' id="menu-button" style="font-size: 30px;"></i>
    <i class='bx bx-cog customize-button' id="customize-button" style="font-size: 20px;"></i>
    <div id="color-picker">
        <label for="navbar-color">Choose navbar color:</label>
        <input type="color" id="navbar-color" name="navbar-color" value="#4CAF50">
    </div>
</header>

  <div id="sidebar" class="sidebar">
    <div class="sidebar-header">
      <i class='bx bx-home-alt' style="font-size: 40px; color: white;"></i>
      <h2>VetEtec</h2>
    </div>
    <a href="javascript:void(0)" class="closebtn" id="close-sidebar"> <i class='bx bxs-chevron-right'></i></a>
   
    
    <a href="<?php echo ($_SESSION['tipo'] == 'veterinario') ? 'veterinario.php' : 'tutor.php'; ?>">
    <i class="bx bx-home"></i><span class="sidebar-text">Início</span>
</a>
    
  <a href="agenda.php"><i class='bx bx-calendar'></i> <span class="sidebar-text">Agenda</span></a>
  <a href="pets.php"><i class='bx bxs-cat'></i> <span class="sidebar-text">Pets</span></a>
  <a href="historico.php"><i class='bx bxs-time'></i> <span class="sidebar-text">Historico</span></a>
  <a href="logout.php" style="margin-top: 100px;">
  <i class='bx bx-log-out'></i> <span class="sidebar-text">Sair</span>
</a>

    <a href="#"><i class='bx bx-moon theme-toggle' id="theme-toggle"></i> <span class="sidebar-text tema">Tema</span></a>
  </div>

  
<body class="bg-green-50 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-8 text-center text-green-600">
            <i class='bx bxs-dog mr-2'></i>Ficha dos Pets
        </h1>
        
        <?php if (count($pets) > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($pets as $pet): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:scale-105">
                        <div class="bg-green-400 text-white p-4">
                            <h2 class="text-xl font-semibold">
                                <i class='bx bxs-cat mr-2'></i><?= htmlspecialchars($pet['nome']) ?>
                            </h2>
                        </div>
                        <div class="p-6">
                            <p class="mb-2"><i class='bx bxs-dog-alt mr-2'></i>Espécie: <?= htmlspecialchars($pet['especie']) ?></p>
                            <p class="mb-2"><i class='bx bxs-bone mr-2'></i>Raça: <?= htmlspecialchars($pet['raca']) ?></p>
                            <p class="mb-4"><i class='bx bxs-calendar mr-2'></i>Idade: <?= htmlspecialchars($pet['idade']) ?> anos</p>
                            
                            <div class="space-y-4">
                                <div>
                                    <h3 class="font-semibold text-green-600"><i class='bx bxs-capsule mr-2'></i>Medicamentos Prescritos:</h3>
                                    <p><?= !empty($pet['medicamentos']) ? htmlspecialchars($pet['medicamentos']) : "Sem medicamentos prescritos." ?></p>
                                </div>
                                
                                <div>
                                    <h3 class="font-semibold text-green-600"><i class='bx bx-test-tube mr-2'></i>Exames Realizados:</h3>
                                    <p><?= !empty($pet['exames']) ? htmlspecialchars($pet['exames']) : "Sem exames realizados." ?></p>
                                </div>
                                
                                <div>
                                    <h3 class="font-semibold text-green-600"><i class='bx bxs-virus mr-2'></i>Histórico de Vacinas:</h3>
                                    <p><?= !empty($pet['vacinas']) ? htmlspecialchars($pet['vacinas']) : "Sem histórico de vacinas." ?></p>
                                </div>
                                
                                <div>
                                    <h3 class="font-semibold text-green-600"><i class='bx bx-plus-medical mr-2'></i>Tratamentos:</h3>
                                    <p><?= !empty($pet['tratamentos']) ? htmlspecialchars($pet['tratamentos']) : "Sem tratamentos registrados." ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-center text-gray-600">Não há pets registrados para este tutor.</p>
        <?php endif; ?>
    </div>



    <footer class="footer">
    <div class="footer-content">
      <h2 class="footer-title">Gestão Veterinária</h2>
      <p class="footer-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at sapien eu justo ultrices feugiat at id quam. Vivamus eu tellus vel ex pretium hendrerit. Phasellus eget vehicula ex, sit amet dictum felis.</p>
      <ul class="footer-links">
        <li><a href="#">Início</a></li>
        <li><a href="#">Sobre</a></li>
        <li><a href="#">Serviços</a></li>
        <li><a href="#">Equipe</a></li>
        <li><a href="#">Contato</a></li>
      </ul>
      <div class="social-icons">
        <a href="#"><img src="https://img.icons8.com/ios-filled/50/ffffff/facebook-new.png" alt="Facebook"></a>
        <a href="#"><img src="https://img.icons8.com/ios-filled/50/ffffff/twitter.png" alt="Twitter"></a>
        <a href="#"><img src="https://img.icons8.com/ios-filled/50/ffffff/linkedin.png" alt="LinkedIn"></a>
        <a href="#"><img src="https://img.icons8.com/ios-filled/50/ffffff/instagram-new.png" alt="Instagram"></a>
      </div>
      <div class="contact-info">
        <div class="contact-info-item">
          <img src="https://img.icons8.com/material-rounded/24/ffffff/phone--v1.png" alt="Telefone">
          +1 234 567 890
        </div>
        <div class="contact-info-item">
          <img src="https://img.icons8.com/material-rounded/24/ffffff/email-open--v1.png" alt="E-mail">
          exemplo@exemplo.com
        </div>
      </div>
      <div class="subscribe">
        <input type="email" class="subscribe-input" placeholder="Digite seu e-mail">
        <button class="subscribe-button">Assinar</button>
      </div>
      <div class="company-info">
        <h3>Sobre Nós</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at sapien eu justo ultrices feugiat at id quam. Vivamus eu tellus vel ex pretium hendrerit. Phasellus eget vehicula ex, sit amet dictum felis.</p>
      </div>
      <div class="quick-links">
        <h3>Links Rápidos</h3>
        <ul>
          <li><a href="#">Política de Privacidade</a></li>
          <li><a href="#">Termos de Serviço</a></li>
          <li><a href="#">FAQ</a></li>
          <li><a href="#">Suporte</a></li>
        </ul>
      </div>
      <div class="about-section">
        <h3>Nossa Missão</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at sapien eu justo ultrices feugiat at id quam. Vivamus eu tellus vel ex pretium hendrerit. Phasellus eget vehicula ex, sit amet dictum felis.</p>
      </div>
      <div class="animal-images">
        <img src="https://placeimg.com/100/100/animals" alt="Animal">
        <img src="https://placeimg.com/100/100/animals" alt="Animal">
        <img src="https://placeimg.com/100/100/animals" alt="Animal">
        <img src="https://placeimg.com/100/100/animals" alt="Animal">
      </div>
    </div>
        
  </footer>
  <script>
    function excluirPet(petId) {
    if (confirm("Tem certeza de que deseja excluir este pet?")) {
        fetch('excluir_pet.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: petId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Pet excluído com sucesso!');
                location.reload(); // Recarregar a página para atualizar a lista
            } else {
                alert('Erro ao excluir pet: ' + data.error);
            }
        })
        .catch(error => console.error('Erro:', error));
    }
}
function editarPet(petId) {
    window.location.href = `editar_pet2.php?id=${petId}`;
}

    </script>
  <script>
        function openModal(id, nome, especie, raca, idade) {
            document.getElementById("editId").value = id;
            document.getElementById("editNome").value = nome;
            document.getElementById("editEspecie").value = especie;
            document.getElementById("editRaca").value = raca;
            document.getElementById("editIdade").value = idade;
            document.getElementById("editModal").classList.remove("hidden");
        }

        function openViewModal(nome, especie, raca, idade) {
            document.getElementById("viewNome").textContent = nome;
            document.getElementById("viewEspecie").textContent = especie;
            document.getElementById("viewRaca").textContent = raca;
            document.getElementById("viewIdade").textContent = idade + " anos";
            document.getElementById("viewModal").classList.remove("hidden");
        }

        function closeModal() {
            document.getElementById("editModal").classList.add("hidden");
            document.getElementById("addModal").classList.add("hidden");
            document.getElementById("viewModal").classList.add("hidden");
        }

        function confirmDelete(id) {
            if (confirm("Tem certeza que deseja excluir este pet?")) {
                document.getElementById("deleteId").value = id;
                document.getElementById("deleteForm").submit();
            }
        }
    </script>
<script>
    const themeToggle = document.getElementById('theme-toggle');
    const customizeButton = document.getElementById('customize-button');
    const colorPicker = document.getElementById('color-picker');
    const navbar = document.getElementById('navbar');
    const body = document.body;
    const sidebar = document.getElementById('sidebar');
    const menuButton = document.getElementById('menu-button');
    const closeSidebar = document.getElementById('close-sidebar');
    let customNavbarColor = '#afd4c3'; // Cor padrão da barra de navegação e da barra lateral
    themeToggle.addEventListener('click', () => {
      body.classList.toggle('dark-theme');
      themeToggle.classList.toggle('bx-sun');
      // Restaurar a cor personalizada ao alternar entre temas claro e escuro
      if (body.classList.contains('dark-theme')) {
        navbar.style.backgroundColor = '#121212'; // Cor de fundo padrão do tema escuro
        sidebar.style.backgroundColor = '#121212'; // Cor de fundo padrão do tema escuro para a barra lateral
      } else {
        navbar.style.backgroundColor = customNavbarColor; // Restaurar a cor personalizada da barra de navegação
        sidebar.style.backgroundColor = customNavbarColor; // Restaurar a cor personalizada da barra lateral
      }
    });
    customizeButton.addEventListener('click', () => {
      colorPicker.style.display = colorPicker.style.display === 'block' ? 'none' : 'block';
    });
    document.getElementById('navbar-color').addEventListener('input', (event) => {
      customNavbarColor = event.target.value; // Armazenar a cor personalizada
      navbar.style.backgroundColor = customNavbarColor; // Atualizar a cor da barra de navegação
      sidebar.style.backgroundColor = customNavbarColor; // Atualizar a cor da barra lateral
    });
    menuButton.addEventListener('click', () => {
      sidebar.style.left = '0';
      navbar.style.transform = 'translateY(-100%)';
    });
    closeSidebar.addEventListener('click', () => {
      sidebar.style.left = '-250px';
      navbar.style.transform = 'translateY(0)';
    });
    document.getElementById('customize-button').addEventListener('click', function () {
      this.classList.toggle('rotated'); // Adiciona ou remove a classe 'rotated' ao clicar
    });
    document.addEventListener('DOMContentLoaded', function () {
      var conteudo = document.querySelector('.conteudo');
      setTimeout(function () {
        conteudo.classList.add('entrou');
      }, 500); // Ajuste o tempo conforme necessário
    });
    function verNotificacoes() {
      alert("Você clicou na notificação. Aqui você pode redirecionar para uma página de detalhes ou abrir um modal com mais informações.");
    }


  </script>


</body>
</html>

